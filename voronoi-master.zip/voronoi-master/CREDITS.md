Proper credits to the authors of some libraries used in this project will be added here.
[-] Starter Code - [Matt Brubeck](https://www.cs.hmc.edu/~mbrubeck/voronoi.html) 
